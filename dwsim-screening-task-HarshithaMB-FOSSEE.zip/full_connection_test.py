import os
import sys

DWSIM_PATH = r"C:\Users\Harshitha\AppData\Local\DWSIM"

print("=" * 60)
print("FULL DWSIM CONNECTION TEST")
print("=" * 60)

if not os.path.exists(DWSIM_PATH):
    print(f"ERROR: DWSIM path not found:\n{DWSIM_PATH}")
    sys.exit(1)

# Add DWSIM path
sys.path.append(DWSIM_PATH)
os.chdir(DWSIM_PATH)

# Import pythonnet CLR
try:
    import clr
    print("[OK] pythonnet/clr loaded")
except Exception as e:
    print("[ERROR] Could not import clr. Install pythonnet first:")
    print("pip install pythonnet")
    print("Details:", e)
    sys.exit(1)

# Try loading assemblies by full DLL path
dlls_to_try = [
    "CapeOpen.dll",
    "DWSIM.Automation.dll",
    "DWSIM.Interfaces.dll",
    "DWSIM.GlobalSettings.dll",
    "DWSIM.SharedClasses.dll",
    "DWSIM.Thermodynamics.dll",
    "DWSIM.UnitOperations.dll",
]

loaded = []
missing = []

print("\nLoading DWSIM DLLs...")
for dll in dlls_to_try:
    full_path = os.path.join(DWSIM_PATH, dll)
    if os.path.exists(full_path):
        try:
            clr.AddReference(full_path)
            loaded.append(dll)
            print(f"[OK] Loaded: {dll}")
        except Exception as e:
            print(f"[FAIL] Could not load: {dll}")
            print(f"       {e}")
    else:
        missing.append(dll)
        print(f"[MISSING] {dll}")

print("\nLoaded DLLs:", loaded)
print("Missing DLLs:", missing)

# Now try importing Automation3 only
try:
    from DWSIM.Automation import Automation3
    print("\n[OK] Imported Automation3")
except Exception as e:
    print("\n[ERROR] Could not import Automation3")
    print("Details:", e)
    sys.exit(1)

# Try creating automation manager and flowsheet
try:
    interf = Automation3()
    sim = interf.CreateFlowsheet()
    print("[OK] Automation manager created")
    print("[OK] Blank flowsheet created successfully")
    print("\n✅ FULL CONNECTION SUCCESSFUL!")
except Exception as e:
    print("\n[ERROR] Automation loaded but flowsheet creation failed")
    print("Details:", e)
    sys.exit(1)

print("=" * 60)