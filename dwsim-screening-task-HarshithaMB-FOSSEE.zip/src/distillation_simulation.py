import os
from dwsim_loader import load_dwsim


def _safe_get_compound_molar_flow(stream, compound_name):
    try:
        return stream.GetOverallCompoundMolarFlow(compound_name)
    except Exception:
        pass

    try:
        return stream.Phases[0].Compounds[compound_name].MolarFlow
    except Exception:
        pass

    try:
        return stream.GetPhase("Overall").Compounds[compound_name].MolarFlow
    except Exception:
        pass

    return None


def run_column_case(
    n_stages=10,
    feed_stage=6,
    reflux_ratio=2.0,
    feed_temp_k=350.0,
    feed_pressure_pa=101325.0,
    total_feed_molar_flow=100.0,
    feed_comp_npentane=0.5,
    distillate_flow=45.0,
):
    env = load_dwsim()
    Automation3 = env["Automation3"]

    manager = Automation3()
    sim = manager.CreateFlowsheet()

    try:
        sim.AddCompound("n-Pentane")
        sim.AddCompound("Isopentane")

        sim.CreateAndAddPropertyPackage("Raoult's Law")

        feed = sim.AddFlowsheetObject("Material Stream", "FEED").GetAsObject()
        distillate = sim.AddFlowsheetObject("Material Stream", "DIST").GetAsObject()
        bottoms = sim.AddFlowsheetObject("Material Stream", "BOTT").GetAsObject()
        qcond = sim.AddFlowsheetObject("Energy Stream", "QCOND").GetAsObject()
        qreb = sim.AddFlowsheetObject("Energy Stream", "QREB").GetAsObject()
        column = sim.AddFlowsheetObject("Distillation Column", "C1").GetAsObject()

        feed_np = total_feed_molar_flow * feed_comp_npentane
        feed_ip = total_feed_molar_flow * (1.0 - feed_comp_npentane)

        feed.SetTemperature(feed_temp_k)
        feed.SetPressure(feed_pressure_pa)
        feed.SetMolarFlow(total_feed_molar_flow)
        feed.SetOverallCompoundMolarFlow("n-Pentane", feed_np)
        feed.SetOverallCompoundMolarFlow("Isopentane", feed_ip)

        if n_stages < 4:
            n_stages = 4
        if feed_stage < 1:
            feed_stage = 1
        if feed_stage > n_stages:
            feed_stage = n_stages

        try:
            column.SetNumberOfStages(n_stages)
        except Exception:
            try:
                column.NumberOfStages = n_stages
            except Exception:
                pass

        # Verified column connection style from DWSIM automation sample
        column.ConnectFeed(feed, feed_stage)
        column.ConnectDistillate(distillate)
        column.ConnectBottoms(bottoms)

        # Try to connect energy streams if supported in your build
        try:
            column.ConnectCondenserDuty(qcond)
        except Exception:
            pass

        try:
            column.ConnectReboilerDuty(qreb)
        except Exception:
            pass

        try:
            column.RefluxRatio = reflux_ratio
        except Exception:
            pass

        try:
            column.DistillateFlowRate = distillate_flow
        except Exception:
            pass

        try:
            column.TotalCondenser = True
        except Exception:
            pass

        try:
            column.CondenserDeltaP = 0.0
        except Exception:
            pass

        try:
            column.ColumnPressureDrop = 0.0
        except Exception:
            pass

        try:
            sim.NaturalLayout()
        except Exception:
            try:
                sim.AutoLayout()
            except Exception:
                pass

        errors = manager.CalculateFlowsheet4(sim)

        np_dist = _safe_get_compound_molar_flow(distillate, "n-Pentane")
        ip_dist = _safe_get_compound_molar_flow(distillate, "Isopentane")
        np_bott = _safe_get_compound_molar_flow(bottoms, "n-Pentane")
        ip_bott = _safe_get_compound_molar_flow(bottoms, "Isopentane")

        dist_total = None
        bott_total = None

        try:
            if np_dist is not None and ip_dist is not None:
                dist_total = np_dist + ip_dist
        except Exception:
            pass

        try:
            if np_bott is not None and ip_bott is not None:
                bott_total = np_bott + ip_bott
        except Exception:
            pass

        dist_ip_purity = None
        bott_np_purity = None

        try:
            if dist_total and dist_total > 0:
                dist_ip_purity = ip_dist / dist_total
        except Exception:
            pass

        try:
            if bott_total and bott_total > 0:
                bott_np_purity = np_bott / bott_total
        except Exception:
            pass

        result = {
            "success": True,
            "error": "",
            "unit_type": "DISTILLATION",
            "n_stages": n_stages,
            "feed_stage": feed_stage,
            "reflux_ratio": reflux_ratio,
            "distillate_flow": distillate_flow,
            "feed_temp_k": feed_temp_k,
            "feed_pressure_pa": feed_pressure_pa,
            "total_feed_molar_flow": total_feed_molar_flow,
            "feed_np_frac": feed_comp_npentane,
            "feed_ip_frac": 1.0 - feed_comp_npentane,
            "dist_np_mol": np_dist,
            "dist_ip_mol": ip_dist,
            "dist_ip_purity": dist_ip_purity,
            "bottom_np_mol": np_bott,
            "bottom_ip_mol": ip_bott,
            "bottom_np_purity": bott_np_purity,
            "cond_duty_kw": None,
            "reb_duty_kw": None,
            "flowsheet_path": None,
        }

        try:
            result["cond_duty_kw"] = qcond.EnergyFlow / 1000.0
        except Exception:
            try:
                result["cond_duty_kw"] = column.CondenserDuty / 1000.0
            except Exception:
                pass

        try:
            result["reb_duty_kw"] = qreb.EnergyFlow / 1000.0
        except Exception:
            try:
                result["reb_duty_kw"] = column.ReboilerDuty / 1000.0
            except Exception:
                pass

        if errors is not None and len(errors) > 0:
            result["success"] = False
            result["error"] = " | ".join([str(e) for e in errors])

        out_dir = os.path.join(os.getcwd(), "outputs")
        os.makedirs(out_dir, exist_ok=True)
        save_path = os.path.join(
            out_dir, f"col_n{n_stages}_r{reflux_ratio}_f{feed_stage}.dwxmz"
        )

        try:
            manager.SaveFlowsheet(sim, save_path, True)
            result["flowsheet_path"] = save_path
        except Exception as e:
            result["flowsheet_path"] = str(e)

        return result

    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "unit_type": "DISTILLATION",
            "n_stages": n_stages,
            "feed_stage": feed_stage,
            "reflux_ratio": reflux_ratio,
            "distillate_flow": distillate_flow,
        }