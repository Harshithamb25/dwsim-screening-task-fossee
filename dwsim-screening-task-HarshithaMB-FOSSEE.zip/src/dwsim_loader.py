import os
import sys

DWSIM_PATH = r"C:\Users\Harshitha\AppData\Local\DWSIM"


def load_dwsim():
    if not os.path.exists(DWSIM_PATH):
        raise FileNotFoundError(f"DWSIM path not found: {DWSIM_PATH}")

    if DWSIM_PATH not in sys.path:
        sys.path.append(DWSIM_PATH)

    os.chdir(DWSIM_PATH)

    import clr

    dlls_to_try = [
        "CapeOpen.dll",
        "DWSIM.Automation.dll",
        "DWSIM.Interfaces.dll",
        "DWSIM.GlobalSettings.dll",
        "DWSIM.SharedClasses.dll",
        "DWSIM.Thermodynamics.dll",
        "DWSIM.UnitOperations.dll",
        "DWSIM.Inspector.dll",
        "System.Buffers.dll",
        "DWSIM.Thermodynamics.ThermoC.dll",
    ]

    loaded = []
    missing = []

    for dll in dlls_to_try:
        full_path = os.path.join(DWSIM_PATH, dll)
        if os.path.exists(full_path):
            try:
                clr.AddReference(full_path)
                loaded.append(dll)
            except Exception:
                pass
        else:
            missing.append(dll)

    from DWSIM.Automation import Automation3

    result = {
        "Automation3": Automation3,
        "loaded_dlls": loaded,
        "missing_dlls": missing,
        "dwsim_path": DWSIM_PATH,
    }

    try:
        from DWSIM.Interfaces.Enums.GraphicObjects import ObjectType
        result["ObjectType"] = ObjectType
    except Exception:
        result["ObjectType"] = None

    try:
        from DWSIM.Thermodynamics import PropertyPackages
        result["PropertyPackages"] = PropertyPackages
    except Exception:
        result["PropertyPackages"] = None

    try:
        from DWSIM.UnitOperations import UnitOperations
        result["UnitOperations"] = UnitOperations
    except Exception:
        result["UnitOperations"] = None

    try:
        from DWSIM.GlobalSettings import Settings
        result["Settings"] = Settings
    except Exception:
        result["Settings"] = None

    return result