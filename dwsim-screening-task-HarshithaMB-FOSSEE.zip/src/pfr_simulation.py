import os
from dwsim_loader import load_dwsim


def _safe_get_compound_molar_flow(stream, compound_name):
    try:
        return stream.GetOverallCompoundMolarFlow(compound_name)
    except Exception:
        pass

    try:
        return stream.Phases[0].Compounds[compound_name].MolarFlow
    except Exception:
        pass

    try:
        return stream.GetPhase("Overall").Compounds[compound_name].MolarFlow
    except Exception:
        pass

    return None


def _create_pentane_isomerization_reaction(sim):
    from System.Collections.Generic import Dictionary

    comps = Dictionary[str, float]()
    comps.Add("n-Pentane", -1.0)
    comps.Add("Isopentane", 1.0)

    dorders = Dictionary[str, float]()
    dorders.Add("n-Pentane", 1.0)
    dorders.Add("Isopentane", 0.0)

    rorders = Dictionary[str, float]()
    rorders.Add("n-Pentane", 0.0)
    rorders.Add("Isopentane", 0.0)

    rxn = sim.CreateKineticReaction(
        "Pentane Isomerization",
        "n-Pentane to Isopentane",
        comps,
        dorders,
        rorders,
        "n-Pentane",
        "Mixture",
        "Molar Concentration",
        "kmol/m3",
        "kmol/[m3.h]",
        0.25,
        5000.0,
        0.0,
        0.0,
        "",
        ""
    )

    sim.AddReaction(rxn)
    sim.AddReactionToSet(rxn.ID, "DefaultSet", True, 0)

    return rxn


def run_pfr_case(
    volume_m3=1.0,
    length_m=1.2,
    feed_temp_k=350.0,
    feed_pressure_pa=101325.0,
    n_pentane_molar_flow=100.0,
    isopentane_molar_flow=0.0,
):
    env = load_dwsim()
    Automation3 = env["Automation3"]

    from DWSIM.Interfaces.Enums.GraphicObjects import ObjectType
    from DWSIM.UnitOperations import Reactors

    manager = Automation3()
    sim = manager.CreateFlowsheet()

    try:
        sim.AddCompound("n-Pentane")
        sim.AddCompound("Isopentane")

        sim.CreateAndAddPropertyPackage("Raoult's Law")

        _create_pentane_isomerization_reaction(sim)

        m1 = sim.AddObject(ObjectType.MaterialStream, 50, 50, "feed").GetAsObject()
        m2 = sim.AddObject(ObjectType.MaterialStream, 220, 50, "product").GetAsObject()
        e1 = sim.AddObject(ObjectType.EnergyStream, 140, 120, "heat").GetAsObject()
        pfr = sim.AddObject(ObjectType.RCT_PFR, 140, 50, "PFR-001").GetAsObject()

        pfr.ConnectFeedMaterialStream(m1, 0)
        pfr.ConnectProductMaterialStream(m2, 0)
        pfr.ConnectFeedEnergyStream(e1, 1)

        try:
            sim.AutoLayout()
        except Exception:
            pass

        m1.SetTemperature(feed_temp_k)
        m1.SetPressure(feed_pressure_pa)
        m1.SetMolarFlow(n_pentane_molar_flow + isopentane_molar_flow)
        m1.SetOverallCompoundMolarFlow("n-Pentane", n_pentane_molar_flow)
        m1.SetOverallCompoundMolarFlow("Isopentane", isopentane_molar_flow)

        pfr.ReactionSetID = "DefaultSet"
        pfr.ReactorOperationMode = Reactors.OperationMode.Isothermic
        pfr.ReactorSizingType = Reactors.Reactor_PFR.SizingType.Length
        pfr.Volume = volume_m3
        pfr.Length = length_m

        errors = manager.CalculateFlowsheet4(sim)

        np_out = _safe_get_compound_molar_flow(m2, "n-Pentane")
        ip_out = _safe_get_compound_molar_flow(m2, "Isopentane")

        conversion = None
        try:
            if np_out is not None and n_pentane_molar_flow > 0:
                conversion = (n_pentane_molar_flow - np_out) / n_pentane_molar_flow
        except Exception:
            pass

        try:
            for c in pfr.ComponentConversions:
                if c.Key == "n-Pentane":
                    conversion = c.Value
        except Exception:
            pass

        result = {
            "success": True,
            "error": "",
            "volume_m3": volume_m3,
            "length_m": length_m,
            "feed_temp_k": feed_temp_k,
            "feed_pressure_pa": feed_pressure_pa,
            "n_pentane_in": n_pentane_molar_flow,
            "isopentane_in": isopentane_molar_flow,
            "n_pentane_out": np_out,
            "isopentane_out": ip_out,
            "conversion": conversion,
            "outlet_temp_k": None,
            "heat_duty_kw": None,
            "flowsheet_path": None,
        }

        try:
            result["outlet_temp_k"] = m2.GetTemperature()
        except Exception:
            pass

        try:
            result["heat_duty_kw"] = pfr.DeltaQ
        except Exception:
            try:
                result["heat_duty_kw"] = e1.EnergyFlow / 1000.0
            except Exception:
                pass

        if errors is not None and len(errors) > 0:
            result["success"] = False
            result["error"] = " | ".join([str(e) for e in errors])

        out_dir = os.path.join(os.getcwd(), "outputs")
        os.makedirs(out_dir, exist_ok=True)
        save_path = os.path.join(out_dir, f"pfr_v{volume_m3}_t{feed_temp_k}.dwxmz")

        try:
            manager.SaveFlowsheet(sim, save_path, True)
            result["flowsheet_path"] = save_path
        except Exception as e:
            result["flowsheet_path"] = str(e)

        return result

    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "volume_m3": volume_m3,
            "length_m": length_m,
            "feed_temp_k": feed_temp_k,
            "feed_pressure_pa": feed_pressure_pa,
        }