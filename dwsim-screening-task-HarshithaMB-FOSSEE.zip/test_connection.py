import os
import sys
import traceback

DWSIM_PATH = r"C:\Users\Harshitha\AppData\Local\DWSIM"

print("=" * 60)
print("DWSIM PYTHON CONNECTION TEST")
print("=" * 60)

# 1) Check installation path
if not os.path.exists(DWSIM_PATH):
    print(f"ERROR: DWSIM path not found:\n{DWSIM_PATH}")
    sys.exit(1)

print(f"[OK] DWSIM folder found:\n{DWSIM_PATH}")

# 2) Add root folder to Python path
if DWSIM_PATH not in sys.path:
    sys.path.append(DWSIM_PATH)

# 3) Look for DLL files in root and first-level subfolders
dll_files = []
for root, dirs, files in os.walk(DWSIM_PATH):
    for f in files:
        if f.lower().endswith(".dll"):
            dll_files.append(os.path.join(root, f))
    if root.count(os.sep) - DWSIM_PATH.count(os.sep) > 1:
        continue

print(f"\nFound {len(dll_files)} DLL file(s).")
for dll in dll_files[:20]:
    print(" -", dll)

# 4) Check specifically for likely automation DLLs
targets = [
    "DWSIM.Automation.dll",
    "DWSIM.Interfaces.dll", 
    "DWSIM.GlobalSettings.dll",
    "DWSIM.SharedClasses.dll",
    "CapeOpen.dll",
]

print("\nSearching for key DWSIM DLLs...")
found_targets = {}
for t in targets:
    found = [x for x in dll_files if os.path.basename(x).lower() == t.lower()]
    found_targets[t] = found
    if found:
        print(f"[FOUND] {t}")
        for p in found:
            print("   ", p)
    else:
        print(f"[MISSING] {t}")

print("\n" + "=" * 60)
print("✅ PATH TEST PASSED!")
print("Next step: install pythonnet and test assembly loading.")
print("=" * 60)