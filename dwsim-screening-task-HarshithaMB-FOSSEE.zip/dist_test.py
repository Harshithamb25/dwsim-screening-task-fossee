import sys
import csv
import os
from datetime import datetime

sys.path.append("src")

from pfr_simulation import run_pfr_case
from distillation_simulation import run_column_case


def run_all_cases():
    all_results = []

    # -----------------------------
    # PART A / C: PFR sweep
    # -----------------------------
    pfr_volumes = [0.1, 0.5, 1.0, 2.0, 5.0]
    for vol in pfr_volumes:
        try:
            r = run_pfr_case(
                volume_m3=vol,
                length_m=1.2,
                feed_temp_k=350.0,
                feed_pressure_pa=101325.0,
                n_pentane_molar_flow=100.0,
                isopentane_molar_flow=0.0,
            )
        except Exception as e:
            r = {
                "success": False,
                "error": str(e),
                "unit_type": "PFR",
                "volume_m3": vol,
                "feed_temp_k": 350.0,
            }
        r["unit_type"] = "PFR"
        r["sweep_group"] = "volume"
        r["timestamp"] = datetime.now().isoformat()
        all_results.append(r)

    pfr_temps = [320, 340, 350, 360, 380]
    for temp in pfr_temps:
        try:
            r = run_pfr_case(
                volume_m3=1.0,
                length_m=1.2,
                feed_temp_k=temp,
                feed_pressure_pa=101325.0,
                n_pentane_molar_flow=100.0,
                isopentane_molar_flow=0.0,
            )
        except Exception as e:
            r = {
                "success": False,
                "error": str(e),
                "unit_type": "PFR",
                "volume_m3": 1.0,
                "feed_temp_k": temp,
            }
        r["unit_type"] = "PFR"
        r["sweep_group"] = "temperature"
        r["timestamp"] = datetime.now().isoformat()
        all_results.append(r)

    # -----------------------------
    # PART B / C: Distillation sweep
    # -----------------------------
    reflux_values = [1.5, 2.0, 3.0, 4.0]
    for rr in reflux_values:
        try:
            r = run_column_case(
                n_stages=10,
                feed_stage=6,
                reflux_ratio=rr,
                feed_temp_k=350.0,
                feed_pressure_pa=101325.0,
                total_feed_molar_flow=100.0,
                feed_comp_npentane=0.5,
                distillate_flow=45.0,
            )
        except Exception as e:
            r = {
                "success": False,
                "error": str(e),
                "unit_type": "DISTILLATION",
                "reflux_ratio": rr,
                "n_stages": 10,
            }
        r["unit_type"] = "DISTILLATION"
        r["sweep_group"] = "reflux_ratio"
        r["timestamp"] = datetime.now().isoformat()
        all_results.append(r)

    stage_values = [8, 10, 12, 15]
    for ns in stage_values:
        try:
            r = run_column_case(
                n_stages=ns,
                feed_stage=min(6, ns),
                reflux_ratio=2.0,
                feed_temp_k=350.0,
                feed_pressure_pa=101325.0,
                total_feed_molar_flow=100.0,
                feed_comp_npentane=0.5,
                distillate_flow=45.0,
            )
        except Exception as e:
            r = {
                "success": False,
                "error": str(e),
                "unit_type": "DISTILLATION",
                "reflux_ratio": 2.0,
                "n_stages": ns,
            }
        r["unit_type"] = "DISTILLATION"
        r["sweep_group"] = "stage_count"
        r["timestamp"] = datetime.now().isoformat()
        all_results.append(r)

    return all_results


def write_results_csv(results, filename="results.csv"):
    columns = set()
    for r in results:
        columns.update(r.keys())

    columns = sorted(columns)

    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for row in results:
            writer.writerow(row)


if __name__ == "__main__":
    print("=" * 60)
    print("DWSIM SCREENING TASK AUTOMATION")
    print("=" * 60)

    results = run_all_cases()
    write_results_csv(results, "results.csv")

    success_count = sum(1 for r in results if r.get("success") is True)
    fail_count = len(results) - success_count

    print(f"Total cases run: {len(results)}")
    print(f"Successful: {success_count}")
    print(f"Failed: {fail_count}")
    print("Saved: results.csv")
    print("=" * 60)