import sys
import csv
import os
from datetime import datetime
from pathlib import Path

sys.path.append("src")

from pfr_simulation import run_pfr_case
from distillation_simulation import run_column_case


def run_all_cases():
    all_results = []

    # -----------------------------
    # PART A / C: PFR sweep
    # -----------------------------
    print("Running PFR sweeps...")
    pfr_volumes = [0.1, 0.5, 1.0, 2.0, 5.0]
    for vol in pfr_volumes:
        try:
            r = run_pfr_case(
                volume_m3=vol,
                length_m=1.2,
                feed_temp_k=350.0,
                feed_pressure_pa=101325.0,
                n_pentane_molar_flow=100.0,
                isopentane_molar_flow=0.0,
            )
        except Exception as e:
            r = {
                "success": False,
                "error": str(e),
                "unit_type": "PFR",
                "volume_m3": vol,
                "feed_temp_k": 350.0,
            }
        r["unit_type"] = "PFR"
        r["sweep_group"] = "volume"
        r["timestamp"] = datetime.now().isoformat()
        all_results.append(r)

    pfr_temps = [320, 340, 350, 360, 380]
    for temp in pfr_temps:
        try:
            r = run_pfr_case(
                volume_m3=1.0,
                length_m=1.2,
                feed_temp_k=temp,
                feed_pressure_pa=101325.0,
                n_pentane_molar_flow=100.0,
                isopentane_molar_flow=0.0,
            )
        except Exception as e:
            r = {
                "success": False,
                "error": str(e),
                "unit_type": "PFR",
                "volume_m3": 1.0,
                "feed_temp_k": temp,
            }
        r["unit_type"] = "PFR"
        r["sweep_group"] = "temperature"
        r["timestamp"] = datetime.now().isoformat()
        all_results.append(r)

    # -----------------------------
    # PART B / C: Distillation sweep
    # -----------------------------
    print("Running Distillation sweeps...")
    reflux_values = [1.5, 2.0, 3.0, 4.0]
    for rr in reflux_values:
        try:
            r = run_column_case(
                n_stages=10,
                feed_stage=6,
                reflux_ratio=rr,
                feed_temp_k=350.0,
                feed_pressure_pa=101325.0,
                total_feed_molar_flow=100.0,
                feed_comp_npentane=0.5,
                distillate_flow=45.0,
            )
        except Exception as e:
            r = {
                "success": False,
                "error": str(e),
                "unit_type": "DISTILLATION",
                "reflux_ratio": rr,
                "n_stages": 10,
            }
        r["unit_type"] = "DISTILLATION"
        r["sweep_group"] = "reflux_ratio"
        r["timestamp"] = datetime.now().isoformat()
        all_results.append(r)

    stage_values = [8, 10, 12, 15]
    for ns in stage_values:
        try:
            r = run_column_case(
                n_stages=ns,
                feed_stage=min(6, ns),
                reflux_ratio=2.0,
                feed_temp_k=350.0,
                feed_pressure_pa=101325.0,
                total_feed_molar_flow=100.0,
                feed_comp_npentane=0.5,
                distillate_flow=45.0,
            )
        except Exception as e:
            r = {
                "success": False,
                "error": str(e),
                "unit_type": "DISTILLATION",
                "reflux_ratio": 2.0,
                "n_stages": ns,
            }
        r["unit_type"] = "DISTILLATION"
        r["sweep_group"] = "stage_count"
        r["timestamp"] = datetime.now().isoformat()
        all_results.append(r)

    return all_results


def write_results_csv(results):
    # FORCE SAVE TO CURRENT PROJECT FOLDER
    script_dir = Path(__file__).parent.absolute()
    csv_path = script_dir / "results.csv"
    
    # Get ALL columns from all results
    columns = set()
    for r in results:
        columns.update(r.keys())
    columns = sorted(columns)
    
    # Write CSV
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(results)
    
    # DISPLAY CONTENTS IMMEDIATELY
    print("\n" + "="*80)
    print("📊 RESULTS DATA PREVIEW (First 5 rows)")
    print("="*80)
    
    # Print header
    print(",".join(columns[:10]), "..." if len(columns) > 10 else "")
    
    # Print first 5 rows
    for i, row in enumerate(results[:5]):
        line = []
        for col in columns:
            val = row.get(col, "")
            if isinstance(val, (int, float)):
                line.append(f"{val:.4f}" if isinstance(val, float) else str(val))
            elif val is None:
                line.append("")
            else:
                line.append(str(val)[:20])  # Truncate long strings
        print(",".join(line[:10]), "..." if len(line) > 10 else "")
    
    print("="*80)
    print(f"✅ SAVED: {csv_path}")
    print(f"📁 Folder: {script_dir}")
    print(f"📊 Total rows: {len(results)}")
    print(f"💾 File size: {csv_path.stat().st_size} bytes")


if __name__ == "__main__":
    print("=" * 60)
    print("DWSIM SCREENING TASK - FINAL RUN")
    print("=" * 60)

    results = run_all_cases()
    write_results_csv(results)

    success_count = sum(1 for r in results if r.get("success") is True)
    print(f"\n🎉 SUMMARY:")
    print(f"   ✅ Total cases: {len(results)}")
    print(f"   ✅ Successful: {success_count}")
    print(f"   ❌ Failed: {len(results) - success_count}")
    print(f"   📄 results.csv: READY FOR SUBMISSION!")
    print("=" * 60)