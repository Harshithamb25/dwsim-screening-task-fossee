import os
import sys

sys.path.append("src")

from dwsim_loader import load_dwsim

print("=" * 60)
print("MINI FLOWSHEET TEST")
print("=" * 60)

env = load_dwsim()

Automation3 = env["Automation3"]
ObjectType = env["ObjectType"]
PropertyPackages = env["PropertyPackages"]
UnitOperations = env["UnitOperations"]
Settings = env["Settings"]

print("[OK] DWSIM environment loaded")
print("[OK] Loaded DLLs:", env["loaded_dlls"])
print("[INFO] Missing DLLs:", env["missing_dlls"])

if ObjectType is None:
    raise Exception("ObjectType enum could not be imported.")
if PropertyPackages is None:
    raise Exception("PropertyPackages module could not be imported.")
if UnitOperations is None:
    raise Exception("UnitOperations module could not be imported.")
if Settings is None:
    raise Exception("Settings module could not be imported.")

# Create automation manager and flowsheet
interf = Automation3()
sim = interf.CreateFlowsheet()

print("[OK] Blank flowsheet created")

# Add compounds
# Public DWSIM example adds compounds to SelectedCompounds from AvailableCompounds. [page:2]
for cname in ["Water"]:
    comp = sim.AvailableCompounds[cname]
    sim.SelectedCompounds.Add(comp.Name, comp)

print("[OK] Added compound: Water")

# Add objects
m1 = sim.AddObject(ObjectType.MaterialStream, 50, 50, "inlet")
m2 = sim.AddObject(ObjectType.MaterialStream, 200, 50, "outlet")
e1 = sim.AddObject(ObjectType.EnergyStream, 125, 120, "energy")
h1 = sim.AddObject(ObjectType.Heater, 125, 50, "heater")

m1 = m1.GetAsObject()
m2 = m2.GetAsObject()
e1 = e1.GetAsObject()
h1 = h1.GetAsObject()

print("[OK] Added material stream, energy stream, and heater")

# Connect objects
sim.ConnectObjects(m1.GraphicObject, h1.GraphicObject, -1, -1)
sim.ConnectObjects(h1.GraphicObject, m2.GraphicObject, -1, -1)
sim.ConnectObjects(e1.GraphicObject, h1.GraphicObject, -1, -1)

try:
    sim.AutoLayout()
except Exception:
    pass

print("[OK] Connected objects")

# Add property package
stables = PropertyPackages.SteamTablesPropertyPackage()
sim.AddPropertyPackage(stables)

print("[OK] Added Steam Tables property package")

# Set feed conditions
m1.SetTemperature(300.0)   # K
m1.SetPressure(101325.0)   # Pa
m1.SetMassFlow(100.0)      # kg/s

print("[OK] Feed conditions set")

# Set heater spec
h1.CalcMode = UnitOperations.Heater.CalculationMode.OutletTemperature
h1.OutletTemperature = 400.0  # K

print("[OK] Heater outlet temperature set")

# Solve
Settings.SolverMode = 0
errors = interf.CalculateFlowsheet2(sim)

print("[OK] Calculation requested")
print("[INFO] Solver return:", errors)

# Read result
print(f"[RESULT] Heater Heat Load: {h1.DeltaQ} kW")

# Save test flowsheet
save_path = os.path.join(os.getcwd(), "outputs", "mini_flowsheet_test.dwxmz")
os.makedirs(os.path.dirname(save_path), exist_ok=True)

try:
    interf.SaveFlowsheet(sim, save_path, True)
    print(f"[OK] Saved flowsheet to: {save_path}")
except Exception as e:
    print(f"[WARN] Could not save flowsheet: {e}")

print("\n✅ MINI FLOWSHEET TEST COMPLETED")
print("=" * 60)