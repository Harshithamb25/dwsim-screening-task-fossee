import sys
import csv
import os
sys.path.append("src")
from pfr_simulation import run_pfr_case
import matplotlib.pyplot as plt

print("=" * 60)
print("PFR PARAMETRIC SWEEP")
print("=" * 60)

# Sweep 1: Volume (m³) at fixed T=350K
volumes = [0.1, 0.5, 1.0, 2.0, 5.0]
results = []

print("Running volume sweep...")
for vol in volumes:
    result = run_pfr_case(
        volume_m3=vol,
        length_m=1.2,
        feed_temp_k=350.0,
        n_pentane_molar_flow=100.0
    )
    results.append(result)
    print(f"Volume {vol}m³: conversion={result.get('conversion', 0):.4f}")

# Sweep 2: Temperature (K) at fixed V=1.0m³  
temps = [320, 340, 350, 360, 380]
print("\nRunning temperature sweep...")
for temp in temps:
    result = run_pfr_case(
        volume_m3=1.0,
        length_m=1.2,
        feed_temp_k=temp,
        n_pentane_molar_flow=100.0
    )
    results.append(result)
    print(f"Temp {temp}K: conversion={result.get('conversion', 0):.4f}")

# Save results to CSV (screening task requirement)
csv_path = "results_pfr.csv"
with open(csv_path, 'w', newline='') as f:
    if results:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

print(f"\n✅ SAVED: {csv_path}")
print(f"Total cases: {len(results)}")

# Quick plots (optional but impressive)
successful = [r for r in results if r['success']]
if len(successful) > 3:
    plt.figure(figsize=(12, 4))
    
    plt.subplot(1, 2, 1)
    vol_cases = [r for r in successful if r['volume_m3'] in volumes]
    plt.plot([r['volume_m3'] for r in vol_cases], 
             [r.get('conversion', 0)*100 for r in vol_cases], 'o-')
    plt.xlabel('Reactor Volume (m³)')
    plt.ylabel('Conversion (%)')
    plt.title('PFR: Conversion vs Volume')
    plt.grid(True, alpha=0.3)
    
    plt.subplot(1, 2, 2)
    temp_cases = [r for r in successful if r['feed_temp_k'] in temps]
    plt.plot([r['feed_temp_k'] for r in temp_cases], 
             [r.get('conversion', 0)*100 for r in temp_cases], 's-')
    plt.xlabel('Feed Temperature (K)')
    plt.ylabel('Conversion (%)')
    plt.title('PFR: Conversion vs Temperature')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('pfr_sweep_plots.png', dpi=150, bbox_inches='tight')
    plt.show()
    print("✅ PLOTS SAVED: pfr_sweep_plots.png")

print("=" * 60)
print("PFR SCREENING TASK PART A COMPLETE")
print("Files generated:")
print(f"  - {csv_path}")
print("  - pfr_sweep_plots.png")
print("  - outputs/*.dwxmz (individual flowsheets)")
print("=" * 60)